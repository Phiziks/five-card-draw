# Project Details
This spring project contains a simplified version of the Wamly One-Way video interview platform.
It will be used as the base of a technical assessment that has been designed to model real
scenarios in the Wamly application.


## Existing Entities
The following entities have been implemented:

- Interview: An interview that was completed by a candidate
- Answer: An answer given by a candidate during an interview. Candidates will give several answers during an interview. 
- User: A Wamly user that can view interviews submitted by candidates. (NOTE: A candidate is not a User.)

Each entity also has a corresponding JpaRepository to persist the entities.
See the following database relationship diagram and source code documentation for more information.
![img.png](db.png)

## Controllers
The project also includes several controllers that perform basic CRUD operations.
The API is documented in the controller source code and can be explored/used through [Swagger UI](http://localhost:3000/swagger-ui/index.html) when the app is running.

## Database

The project has been configured to use an H2 file-based DB that allows you to use the JPA repositories and have your data persisted across runs without having to configure a local DB.

The DB is pre-populated with some example data. You can use API to explore the DB or use a database connector that supports H2 to browse the data by connecting it to the file.
The DB file is located [here](./db/wamly.mv.db).

**Note:** The file gets locked while the app is running to prevent data corruption. Ensure that the app is stopped before connecting another DB interface to the file.

You can also revert the DB to it's initial state by replacing the file with the original or delete it altogether to start without any data.

# Instructions
Your technical assessment consists of two parts that build on one another.
Make sure to first read the general tips and instructions before reading the instructions to the two parts.

## General Tips & Instructions
Follow these general instructions throughout the challenge to improve your submission:

- Try to adhere to SOLID coding principles.
- Try to write easily readable code.
- Structure your code in a way that promotes reuse and changes in the future.
- Make assumptions where required. Add comments to state your assumptions.
- Use comments as needed to improve readability.
- Add basic documentation (Don't spend a lot of time on this).
- Add basic input validation (Don't spend a lot of time on this.)

### Getting Stuck
If you get stuck with on something that is blocking you, implement a temporary stub or workaround that
allows you to continue with your implementation. For example, if you are struggling to read data from a DB,
use a function that returns hardcoded data instead. Try to come back to the problem once the rest of your task has been completed.
If you are still unable to solve the problem, leave the stub/workaround in your submission. It will be used as a
problem-solving talk point in your follow-up interview.

## Part 1: User Comments
The first part of this challenge is to add a feature that allows Users to make comments on both Interviews and individual interview Answers.

The following requirements should be met:

- A user should be able to add multiple comments to an interview or answer. 
- The time and date that the comment was created should be recorded.

The following assumptions can be made:

- Comments will only include plain-text data.

You should implement the following:

- Add/update any entities and relationships required.
- Add a service to implement the required business logic.
- Add a controller that implements at least the following endpoints:
  - Add a comment.
  - Delete a comment.
  - Edit an existing comment.
  - Get all existing comments.
  - Get all comments for a specific interview
  - Get all comments for a specific answer
  - Get all comments by a specific user.

## Part 2: Comment Analysis
Administrators may want to know whether raters are providing sufficient feedback on interviews through comments.
To help them determine this, implement a feature that analyses comments by counting the number of words in the 
comments and allowing users to query this data.

Create an API that allows a user to query the aggregated sum of the word count for the following:
- All comments.
- Comments made by a specific user.
- Comments made on a specific interview.
- Comments made on a specific answer.

Take note of these additional requirements:
- The analysis should be able to scale to millions/billions of comments without a drop in performance. (HINT: try to minimise the Big O complexity of your implementation.)
- The analysis should include any existing comments that are already in the DB and any new comments that may be made after the implementation of the feature.
- The word count should exclude punctuation and filler words. The words that should be ignored are provided in [this CSV file](src/main/resources/filler_words.csv).

# Build & Run
You can build and run this project in your preferred environment.
Whatever environment you choose, ensure that you install [Java 17 or higher](https://www.oracle.com/java/technologies/downloads/#java17).

## IntelliJ (Recommended)
### Install & Open
Follow [this guide](https://spring.io/guides/gs/intellij-idea/).

### Build & Run
1. Build the project to download all dependencies the required.
2. Run the project.

## VS Code
Follow [this guide](https://spring.io/guides/gs/guides-with-vscode/).

## Maven
### Install Dependencies
Ensure you install the following dependencies:
1. [Java 17 or higher](https://www.oracle.com/java/technologies/downloads/#java17)
2. [Maven 3.5+](https://maven.apache.org/download.cgi)

### Build & Run
1. `cd` to the project root.
2. Open your terminal and run the following command: `mvn spring-boot:run`
