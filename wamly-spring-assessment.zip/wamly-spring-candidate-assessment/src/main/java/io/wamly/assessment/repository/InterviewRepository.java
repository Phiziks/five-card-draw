package io.wamly.assessment.repository;

import io.wamly.assessment.model.Interview;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InterviewRepository extends JpaRepository<Interview, String> {
}