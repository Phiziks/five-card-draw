package io.wamly.assessment.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIdentityReference;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import jakarta.persistence.*;
import lombok.*;

import java.util.Objects;
import java.util.UUID;

/**
 * This entity represents an answer submitted by a candidate to an interview.
 * A candidate can submit multiple answers to an interview.
 */

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "answer")
public class Answer {
    @Id
    @Column(name = "id", nullable = false)
    @Builder.Default
    private String id = UUID.randomUUID().toString();

    @JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
    @JsonIdentityReference(alwaysAsId = true)
    @ManyToOne
    private Interview interview;    //!< The interview this answer belongs to.

    private String content;         //!< The answer content submitted by the candidate.

    /**
     * Updates the answer with new answer information.
     *
     * @param answer The answer object containing updated information
     */
    public void update(Answer answer) {
        this.content = answer.getContent();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Answer answer = (Answer) o;
        return Objects.equals(id, answer.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}